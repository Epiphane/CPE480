/**
 * Convenience object containing references to the possible region owners
 */
PossibleOwners = {
    NEUTRAL: 'neutral',
    OPPONENT: 'opponent',
    PLAYER: 'player',
};